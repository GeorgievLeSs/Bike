<section id="partners">

    <div class="container textAlignCenter">

        <h3>

          Some of our Partners
        </h3>

        <figure>

            <img src="jscss/images/partners/triumfph.jpg" alt="Triumfph">

            <img src="jscss/images/partners/harley-davidson.jpg" alt="Harley-Davidson">

            <img src="jscss/images/partners/honda.jpg" alt="Honda">

            <img src="jscss/images/partners/yamaha.jpg" alt="Yamaha">

            <img src="jscss/images/partners/suzuki.jpg" alt="suzuki">

            <img src="jscss/images/partners/bmw.jpg" alt="BMW">

            <img src="jscss/images/partners/aprilia.jpg" alt="Aprilia">
            
            <img src="jscss/images/partners/cross.jpg" alt="Cross">
        </figure>
    </div>
</section>
