<section id="appMobile">

    <div class="container">

        <div>

            <h1>

              Mobile Applications
            </h1>

            <span>

              Get your no-obligation quotes on the move!
            </span>
        </div>

        <div>
                <a href="#" target="_blank" >

                    <img src="jscss/images/apps/appleG.png" alt="IOS">
                </a>
                <a href="#" target="_blank">

                    <img src="jscss/images/apps/androidG.png" alt="Android">
                </a>
                <a href="#" target="_blank">

                    <img src="jscss/images/apps/windows8.png" alt="Windows Phone">
                </a>
                <a href="#" target="_blank">
                  
                    <img src="jscss/images/apps/amazonA.png" alt="Amazon">
                </a>
        </div>
    </div>
</section>
