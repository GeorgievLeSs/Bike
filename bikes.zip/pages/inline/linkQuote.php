<section id="linkQuote">

    <div class="container">

        <h1>

            All motorbike deals around you at few clicks distance!
        </h1>

        <h2>

            <a href="quote">
              
              Take A Look
            </a>
        </h2>
    </div>
</section>
